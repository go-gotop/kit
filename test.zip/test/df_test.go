package test

import (
	"fmt"
	"sync"
	"testing"
	"time"

	"github.com/go-gotop/kit/dfmanager"
	"github.com/go-gotop/kit/dfmanager/dfbinance"
	"github.com/go-gotop/kit/dfmanager/dffile"
	"github.com/go-gotop/kit/dfmanager/dfmock"
	"github.com/go-gotop/kit/exchange"
	"github.com/go-gotop/kit/limiter/bnlimiter"
	"github.com/go-gotop/kit/limiter/molimiter"
	"github.com/go-gotop/kit/wsmanager/manager"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"github.com/stretchr/testify/assert"
)

func messageEvent(data *exchange.TradeEvent) {
	fmt.Printf("TradeEvent: %v\n", data)
}

func errEvent(err error) {
	if err == manager.ErrServerClosedConn {
		fmt.Println("Server closed connection")
		return
	}
	fmt.Printf("Error: %v\n", err)
}

func newRedis() *redis.Client {
	rdb := redis.NewClient(&redis.Options{
		Addr:     "192.168.100.3:6379", // Redis 服务器地址
		Password: "94nTh96eTsHEuurvO8JQrDlHfa3gF1Np",
		DB:       0, // 使用的数据库编号
	})
	return rdb
}

func TestNewBinanceDataFeed(t *testing.T) {
	// 默认配置

	limiter := bnlimiter.NewBinanceLimiter(newRedis())

	df := dfbinance.NewBinanceDataFeed(limiter,dfbinance.WithMaxConnDuration(30*time.Second))
	assert.NotNil(t, df)

	var wg sync.WaitGroup
	wg.Add(1) // 为三个协程设置等待组

	for i := 0; i < 1; i++ {
		go func(i int) {
			defer wg.Done() // 协程结束时通知WaitGroup

			uuid := uuid.New().String()
			err := df.AddDataFeed(&dfmanager.DataFeedRequest{
				ID:           uuid,
				Symbol:       "TRUUSDT",
				Instrument:   exchange.InstrumentTypeMargin,
				Event:        messageEvent,
				ErrorHandler: errEvent,
			})

			assert.Nil(t, err)
		}(i)
	}

	wg.Wait() // 等待所有协程完成
	time.Sleep(30 * time.Second)
}

func TestNewBinanceMarkDataFeed(t *testing.T) {
	limiter := bnlimiter.NewBinanceLimiter(newRedis())
	df := dfbinance.NewBinanceDataFeed(limiter)
	assert.NotNil(t, df)
	uuid := uuid.New().String()
	err := df.AddMarketPriceDataFeed(&dfmanager.MarkPriceRequest{
		ID:         uuid,
		Instrument: exchange.InstrumentTypeFutures,
		Symbol:    "BTCUSDT",
		Event: func(data *exchange.MarkPriceEvent) {
			fmt.Printf("data: %v\n", data)
		},
		ErrorHandler: func(err error) {
			fmt.Printf("Error: %v\n", err)
		},
	})

	assert.Nil(t, err)

	time.Sleep(10 * time.Minute)
}

// func TestMockMarkDataFeed(t *testing.T) {
// 	limiter := molimiter.NewMockLimiter(newRedis())
// 	df := dfmock.NewMockDataFeed(limiter)

// 	uuid := uuid.New().String()
// 	err := df.AddMarketPriceDataFeed(&dfmanager.MarkPriceRequest{
// 		ID:         uuid,
// 		Instrument: exchange.InstrumentTypeFutures,
// 		StartTime:  1698796800000,
// 		EndTime:    1720584000000,
// 		Event: func(data []*exchange.MarkPriceEvent) {
// 			fmt.Printf("data: %v\n", data)
// 		},
// 		ErrorHandler: func(err error) {
// 			fmt.Printf("Error: %v\n", err)
// 		},
// 	})

// 	assert.Nil(t, err)

// 	time.Sleep(10 * time.Second)
// }

func TestKlineDataFeed(t *testing.T) {
	limiter := molimiter.NewMockLimiter(newRedis())
	df := dfmock.NewMockDataFeed(limiter, dfmock.WithWsEndpoint("ws://192.168.100.3:8072/ws/data"))
	assert.NotNil(t, df)
	uuid := uuid.New().String()
	err := df.AddKlineDataFeed(&dfmanager.KlineRequest{
		ID:           uuid,
		Symbol:       "ETHUSDT_240628",
		Instrument:   exchange.InstrumentTypeFutures,
		Period:       "1m",
		StartTime:    1712995320000,
		EndTime:      1718265720000,
		Event:        func(data *exchange.KlineEvent) { fmt.Printf("KlineEvent: %v\n", data) },
		ErrorHandler: errEvent,
	})

	assert.Nil(t, err)

	time.Sleep(10 * time.Second)
}

// 测试closeDatafeed
func TestCloseDataFeed(t *testing.T) {
	// 默认配置

	limiter := bnlimiter.NewBinanceLimiter(newRedis())

	df := dfbinance.NewBinanceDataFeed(limiter)
	assert.NotNil(t, df)
	uuid := uuid.New().String()
	err := df.AddDataFeed(&dfmanager.DataFeedRequest{
		ID:           uuid,
		Symbol:       "BTCUSDT",
		Instrument:   exchange.InstrumentTypeSpot,
		Event:        messageEvent,
		ErrorHandler: errEvent,
	})

	assert.Nil(t, err)
	time.Sleep(30 * time.Second)
	err = df.CloseDataFeed(uuid)
	assert.Nil(t, err)

	time.Sleep(10 * time.Second)

	l := df.DataFeedList()
	fmt.Println(l)
	assert.Equal(t, 0, len(l))

}

func TestFileDataFeed(t *testing.T) {

	// basePath, err := filepath.Abs(".")
	// fmt.Println(basePath)

	df := dffile.NewFileDataFeed(dffile.WithPath("/Users/imac/go/src/kit/test/data/binance/spot/trades/BTCUSDT/"))

	err := df.AddDataFeed(&dfmanager.DataFeedRequest{
		ID:           "1",
		Symbol:       "BTCUSDT",
		StartTime:    1717200000001,
		EndTime:      1717210796037,
		Instrument:   exchange.InstrumentTypeSpot,
		Event:        messageEvent,
		ErrorHandler: errEvent,
	})

	if err != nil {
		fmt.Printf("Error: %v\n", err)
	}

	time.Sleep(10 * time.Second)

	// err = df.CloseDataFeed("1")
	// if err != nil {
	// 	fmt.Printf("Error: %v\n", err)
	// } else {
	// 	fmt.Println("CloseDataFeed success")
	// }

	// time.Sleep(60 * time.Second)
}
