package test

import (
	"fmt"
	"os"
	"testing"

	"github.com/go-gotop/kit/kitutils"
)

const (
	ACCAPIKEY  = "FptRCB1ZNK9dpg0Uyz+0A07KCvuCyOaCgROO6en++HtBUX+duJh+jMq1U+yWBmMgBj5JrVNo+DOqMt+Zb8kPmRTimd7ZZ9rp1m/AKg=="
	ACCSECRET  = "qLQYviKLs1/1ZFbUuJscdQTGEFhHvXuPMnGeq7g1rOesxCPRImyF552vA6SiymAc3eUROpOxHCaD631Nw10WJGiyUPrbdjlh"
	Passphrase = "kB61qGGhdq0hui3l+fEeAXPSdCkTuEeHEhWQjddI4jxb/WdswH8omuliBFUgr2lrYw=="
)

func Test_DecryptStr(t *testing.T) {
	os.Setenv("ENCRYPTION_KEY", "qwtShba5v86OXr73y1bnGIr38oN57aF8")
	key := kitutils.LoadEncryptionKey()
	apiKey, _ := kitutils.Decrypt(ACCAPIKEY, key)
	secret, _ := kitutils.Decrypt(ACCSECRET, key)
	passphrase, _ := kitutils.Decrypt(Passphrase, key)

	fmt.Println("apiKey: ", apiKey)
	fmt.Println("secret: ", secret)
	fmt.Println("passphrase: ", passphrase)
}
