package test

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"os/signal"
	"syscall"
	"testing"
	"time"

	"github.com/go-kratos/kratos/v2/log"
	// kafkaGo "github.com/segmentio/kafka-go"
	"github.com/stretchr/testify/assert"

	// "go.opentelemetry.io/otel/trace"

	api "github.com/go-gotop/kit/test/manual"

	"github.com/go-gotop/kit/broker"
	"github.com/go-gotop/kit/broker/kafka"
	"github.com/go-gotop/kit/tracing"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/exporters/zipkin"
	"go.opentelemetry.io/otel/propagation"
	"go.opentelemetry.io/otel/sdk/resource"

	traceSdk "go.opentelemetry.io/otel/sdk/trace"
	semconv "go.opentelemetry.io/otel/semconv/v1.12.0"
	"go.opentelemetry.io/otel/trace"
)

const (
	testBrokers = "10.0.0.141:9094"
	// testBrokers = "192.168.1.107:9094"
	testTopic   = "munal_test"
	testGroupId = "fx-group1"
	// certFile    = "../keystore/server/client-signed.crt"
	clientKey  = "./tls/client-key.pem"
	clientCert = "./tls/client-cert.pem"
	caFile     = "./tls/ca-cert.pem"
)

var brokersList = []string{"192.168.1.224:9094", "192.168.1.240:9094"}

func generateTlsConfig() *tls.Config {
	// 读取 CA 证书
	caCert, err := os.ReadFile(caFile)
	if err != nil {
		log.Fatalf("failed to read CA cert: %v", err)
	}

	// 创建 cert pool 并添加 CA 证书
	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)

	// clientCert, err := tls.LoadX509KeyPair("client-cert.pem", "client-key.pem")

	// 加载客户端证书和密钥
	// cert, err := tls.LoadX509KeyPair(clientCert, clientKey)
	if err != nil {
		log.Fatalf("failed to load client cert and key: %v", err)
	}
	// 创建并返回 TLS 配置
	return &tls.Config{
		// Certificates: []tls.Certificate{cert}, // 客户端证书
		RootCAs: caCertPool,
		// InsecureSkipVerify: false,
	}
}

func handleHygrothermograph(_ context.Context, topic string, headers broker.Headers, msg *api.Hygrothermograph) error {
	log.Infof("Topic %s, Headers: %+v, Payload: %+v\n", topic, headers, msg)
	return nil
}

func Test_Publish_WithRawData(t *testing.T) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	ctx := context.Background()

	b := kafka.NewBroker(
		log.NewHelper(log.DefaultLogger),
		broker.WithAddress(testBrokers),
		// broker.WithTLSConfig(generateTlsConfig()),
		broker.OptionContextWithValue("batchTimeoutKey", 1*time.Millisecond),
	)

	_ = b.Init()

	if err := b.Connect(); err != nil {
		t.Logf("cant connect to broker, skip: %v", err)
		t.Skip()
	}
	defer b.Disconnect()

	var msg api.Hygrothermograph
	const count = 10
	for i := 0; i < count; i++ {
		startTime := time.Now()
		msg.Humidity = float64(rand.Intn(100))
		msg.Temperature = float64(rand.Intn(100))
		buf, _ := json.Marshal(&msg)
		err := b.Publish(ctx, testTopic, buf)
		assert.Nil(t, err)
		elapsedTime := time.Since(startTime) / time.Millisecond
		fmt.Printf("Publish %d, elapsed time: %dms, Humidity: %.2f Temperature: %.2f\n",
			i, elapsedTime, msg.Humidity, msg.Temperature)
	}

	fmt.Printf("total send %d messages\n", count)

	<-interrupt
}

func Test_Subscribe_WithRawData(t *testing.T) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	b := kafka.NewBroker(
		log.NewHelper(log.DefaultLogger),
		broker.WithAddress(testBrokers),
		// broker.WithTLSConfig(generateTlsConfig()),
		broker.OptionContextWithValue("batchTimeoutKey", 1*time.Millisecond),
		broker.OptionContextWithValue("maxWaitKey", 1*time.Second),
	)

	_ = b.Init()

	if err := b.Connect(); err != nil {
		t.Logf("cant connect to broker, skip: %v", err)
		t.Skip()
	}
	defer b.Disconnect()

	_, err := b.Subscribe(testTopic,
		api.RegisterHygrothermographRawHandler(handleHygrothermograph),
		nil,
		// broker.WithQueueName(testGroupId),
	)
	assert.Nil(t, err)
	assert.Nil(t, err)

	<-interrupt
}

func Test_Publish_WithJsonCodec(t *testing.T) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	ctx := context.Background()

	b := kafka.NewBroker(
		log.NewHelper(log.DefaultLogger),
		broker.WithAddress(testBrokers),
		broker.WithCodec("json"),
		//WithAsync(false),
	)

	_ = b.Init()

	if err := b.Connect(); err != nil {
		t.Logf("cant connect to broker, skip: %v", err)
		t.Skip()
	}
	defer b.Disconnect()

	var headers map[string]interface{}
	headers = make(map[string]interface{})
	headers["version"] = "1.0.0"

	var msg api.Hygrothermograph
	const count = 10
	for i := 0; i < count; i++ {
		startTime := time.Now()
		headers["trace_id"] = i
		msg.Humidity = float64(rand.Intn(100))
		msg.Temperature = float64(rand.Intn(100))
		err := b.Publish(ctx, testTopic, msg, kafka.WithHeaders(headers))
		assert.Nil(t, err)
		elapsedTime := time.Since(startTime) / time.Millisecond
		log.Infof("Publish %d, elapsed time: %dms, Humidity: %.2f Temperature: %.2f\n",
			i, elapsedTime, msg.Humidity, msg.Temperature)
	}

	log.Infof("total send %d messages\n", count)

	<-interrupt
}

func Test_Subscribe_WithJsonCodec(t *testing.T) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	b := kafka.NewBroker(
		log.NewHelper(log.DefaultLogger),
		broker.WithAddress(testBrokers),
		broker.WithCodec("json"),
	)

	_ = b.Init()

	if err := b.Connect(); err != nil {
		t.Logf("cant connect to broker, skip: %v", err)
		t.Skip()
	}
	defer b.Disconnect()

	_, err := b.Subscribe(testTopic,
		api.RegisterHygrothermographJsonHandler(handleHygrothermograph),
		api.HygrothermographCreator,
		// broker.WithQueueName(testGroupId),
	)
	assert.Nil(t, err)

	<-interrupt
}

func createTracerProvider(exporterName, serviceName string) broker.Option {
	return broker.WithTracerProvider(tracing.NewTracerProvider(exporterName,
		"http://10.0.0.6:9411/api/v2/spans",
		serviceName,
		"test",
		"1.0.0",
		1.0,
	),
		"kafka-tracer",
	)
}

func Test_Publish_WithTracer(t *testing.T) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	ctx := context.Background()

	b := kafka.NewBroker(
		log.NewHelper(log.DefaultLogger),
		broker.WithAddress(testBrokers),
		broker.WithCodec("json"),
		createTracerProvider("zipkin", "tracer_tester"),
	)

	_ = b.Init()

	if err := b.Connect(); err != nil {
		t.Logf("cant connect to broker, skip: %v", err)
		t.Skip()
	}
	defer b.Disconnect()

	var msg api.Hygrothermograph
	const count = 1
	for i := 0; i < count; i++ {
		startTime := time.Now()
		msg.Humidity = float64(rand.Intn(100))
		msg.Temperature = float64(rand.Intn(100))
		err := b.Publish(ctx, "order-event", msg)
		assert.Nil(t, err)
		elapsedTime := time.Since(startTime) / time.Millisecond
		log.Infof("Publish %d, elapsed time: %dms, Humidity: %.2f Temperature: %.2f\n",
			i, elapsedTime, msg.Humidity, msg.Temperature)
	}

	log.Infof("total send %d messages\n", count)

	<-interrupt
}

func Test_Subscribe_WithTracer(t *testing.T) {
	interrupt := make(chan os.Signal, 1)
	signal.Notify(interrupt, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT)

	b := kafka.NewBroker(
		log.NewHelper(log.DefaultLogger),
		broker.WithAddress(testBrokers),
		broker.WithCodec("json"),
		createTracerProvider("zipkin", "subscribe_tracer_tester"),
	)

	_ = b.Init()

	if err := b.Connect(); err != nil {
		t.Logf("cant connect to broker, skip: %v", err)
		t.Skip()
	}
	defer b.Disconnect()

	_, err := b.Subscribe("order-event",
		api.RegisterHygrothermographJsonHandler(handleHygrothermograph),
		api.HygrothermographCreator,
		// broker.WithQueueName(testGroupId),
	)
	assert.Nil(t, err)

	<-interrupt
}

func Test_Tracing(t *testing.T) {
	provider := tracing.NewTracerProvider("zipkin",
		"http://10.0.0.6:9411/api/v2/spans",
		"test1",
		"test1",
		"1.0.0",
		1.0,
	)
	defer provider.Shutdown(context.Background()) // 在程序结束时关闭provider
	// msg := &kafkaGo.Message{
	// 	Value: []byte("message value"),
	// }
	data1 := make(map[string]string)
	// msg2 := &kafkaGo.Message{
	// 	Value: []byte("message value"),
	// }
	attrs := []attribute.KeyValue{
		attribute.String("id", "123456"),
	}

	opt := tracing.WithTracerProvider(provider)
	producerTracer := tracing.NewTracer(trace.SpanKindProducer, "kafka-producer", opt)
	consumerTracer := tracing.NewTracer(trace.SpanKindConsumer, "kafka-consumer", opt)
	// producer
	// carrier := kafka.NewMessageCarrier(msg)
	carrier := propagation.MapCarrier(data1)
	ctx, span := producerTracer.Start(context.Background(), carrier, attrs...)
	producerTracer.End(ctx, span, nil)

	jsonData, err := json.Marshal(data1)
	if err != nil {
		log.Fatalf("Failed to marshal data: %v", err)
	}
	data2 := map[string]string{}
	err = json.Unmarshal(jsonData, &data2)
	if err != nil {
		log.Fatalf("Failed to unmarshal data: %v", err)
	}

	// consumer
	carrier2 := propagation.MapCarrier(data2)
	ctx, span = consumerTracer.Start(context.Background(), carrier2, attrs...)
	consumerTracer.End(ctx, span, nil)

	time.Sleep(10 * time.Second)

}

func Test_Trace_backup(t *testing.T) {
	// 配置并创建Zipkin导出器
	exporter, err := zipkin.New(
		"http://10.0.0.6:9411/api/v2/spans",
		// zipkin.WithLogger(log.New(os.Stderr, "", log.LstdFlags)),
	)
	if err != nil {
		log.Fatalf("Failed to create Zipkin exporter: %v", err)
	}

	// 创建Tracer provider
	tp := traceSdk.NewTracerProvider(
		traceSdk.WithBatcher(exporter),
		traceSdk.WithResource(resource.NewWithAttributes(
			semconv.SchemaURL,
			semconv.ServiceNameKey.String("ExampleService"),
		)),
	)
	defer tp.Shutdown(context.Background())

	// 设置全局Tracer provider
	otel.SetTracerProvider(tp)

	// 获取Tracer
	tracer := otel.Tracer("example-tracer")

	// 从请求中启动一个新的Span
	_, span := tracer.Start(context.Background(), "server-request")
	defer span.End()

	// 追踪一些自定义事件
	span.AddEvent("handling request event")

	// // 创建HTTP处理器
	// handler := http.NewServeMux()
	// handler.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {

	// 	// 在函数中使用context
	// 	doWork(ctx)
	// })

}
