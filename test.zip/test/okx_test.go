package test

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sync"
	"testing"
	"time"

	"github.com/go-gotop/kit/dfmanager"
	"github.com/go-gotop/kit/dfmanager/dfokx"
	"github.com/go-gotop/kit/exchange"
	"github.com/go-gotop/kit/exchange/okexc"
	"github.com/go-gotop/kit/limiter/okxlimiter"
	"github.com/go-gotop/kit/requests/okhttp"
	"github.com/go-gotop/kit/streammanager"
	"github.com/go-gotop/kit/streammanager/streamokx"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
)

const (
	OKAPIKey     = "9802a0bc-5c21-4fd3-b9fb-10303ff3fb22"
	OKAPISecret  = "CD12E95E6917E249234BDEE8FD40F13E"
	OKPASSPHRASE = "Gotop123!@#"
)

func httpClient() *okhttp.Client {
	return okhttp.NewClient()
}

func TestOkxKlineDataFeed(t *testing.T) {
	limiter := okxlimiter.NewOkxLimiter(newRedis())

	df := dfokx.NewOkxDataFeed(limiter)
	uuid := uuid.New().String()
	err := df.AddKlineDataFeed(&dfmanager.KlineRequest{
		ID:           uuid,
		Symbol:       "BTC-USDT-SWAP",
		Period:       "1H",
		StartTime:    0,
		EndTime:      0,
		Instrument:   exchange.InstrumentTypeFutures,
		Event:        func(data *exchange.KlineEvent) { fmt.Printf("KlineEvent: %v\n", data) },
		ErrorHandler: errEvent,
	})

	if err != nil {
		t.Fatal(err)
	}

	// {
	// 	"op":"subscribe",
	// 	"args":[
	// 	   {
	// 		  "channel":"sprd-candle1D",
	// 		  "sprdId":"BTC-USDT_BTC-USDT-SWAP"
	// 	   }
	// 	]
	//  }

	msg := map[string]interface{}{
		"op": "subscribe",
		"args": []map[string]interface{}{
			{
				"channel": "candle1D",
				"instId":  "BTC-USDT",
			},
		},
	}

	msgBytes, err := json.Marshal(msg)
	if err != nil {
		t.Fatal(err)
	}

	time.Sleep(5 * time.Second)

	df.WriteMessage(uuid, msgBytes)

	time.Sleep(10 * time.Minute)

	err = df.CloseDataFeed(uuid)

}

func TestOkxGetKline(t *testing.T) {
	okx := okexc.NewOkx(httpClient())
	kline, err := okx.GetKline(context.Background(), &exchange.GetKlineRequest{
		Symbol:         exchange.Symbol{OriginalSymbol: "BTC-USDT-SWAP"},
		Start:          0,
		End:            0,
		Period:         "1H",
		Limit:          10,
		InstrumentType: exchange.InstrumentTypeFutures,
	})
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range kline {
		fmt.Println(v)
	}
}

func Test_Get_Depth(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)
	depth, err := ex.GetDepth(context.Background(), &exchange.GetDepthRequest{
		Symbol:         exchange.Symbol{OriginalSymbol: "BTC-USDT"},
		Limit:          10,
		InstrumentType: exchange.InstrumentTypeFutures,
	})
	if err != nil {
		t.Fatal(err)
	}

	fmt.Printf("%+v\n", depth)
}

func Test_Get_MaxSize(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)

	maxSize, err := ex.GetMaxSize(context.Background(), &exchange.GetMaxSizeRequest{
		APIKey:     "afa3d119-5858-4d6f-9006-aa4cc59fb60d",
		SecretKey:  "190A1363588D0B38113CBE0D7D04931B",
		Passphrase: "Aa21887236!",
		InstIds:    "BTC-USDT-SWAP",
		TdMode:     "cross",
	})

	if err != nil {
		t.Fatal(err)
	}

	for _, size := range maxSize {
		fmt.Printf("%+v\n", size)
	}
}

func Test_Close_All_Positions(t *testing.T) {
	cli := okhttp.NewClient()
	r := &okhttp.Request{
		APIKey:     "7785315e-4e2a-4631-bbad-3f45705b47f2",
		SecretKey:  "A1DD78E8F058BC74CB090C5B45BFC06F",
		Passphrase: "aXYh@.}aj}v_x@G-3B#J",
		Method:     "POST",
		Endpoint:   "/api/v5/trade/close-position",
		SecType:    okhttp.SecTypeSigned,
	}

	cli.SetApiEndpoint("https://aws.okx.com")
	params := okhttp.Params{
		"instId":  "BTC-USDT",
		"posSide": "net",
		"mgnMode": "cross",
		"ccy":     "USDT",
	}
	r = r.SetJSONBody(params)
	data, err := cli.CallAPI(context.Background(), r)
	if err != nil {
		fmt.Println(err)
	}

	fmt.Println(string(data))
}

func Test_Create_Order(t *testing.T) {
	cli := okhttp.NewClient(okhttp.HttpClient(&http.Client{}))
	ex := okexc.NewOkx(cli)

	err := ex.CreateOrder(context.Background(), &exchange.CreateOrderRequest{
		APIKey:     "afa3d119-5858-4d6f-9006-aa4cc59fb60d",
		SecretKey:  "190A1363588D0B38113CBE0D7D04931B",
		Passphrase: "Aa21887236!",
		Symbol: exchange.Symbol{
			OriginalSymbol: "BTC-USDT",
		},
		Side:         exchange.SideTypeSell,
		OrderType:    exchange.OrderTypeMarket,
		PositionSide: exchange.PositionSideLong,
		Instrument:   exchange.InstrumentTypeSpot,
		Size:         decimal.NewFromFloat(0.00019),
	})
	if err != nil {
		t.Fatal(err)
	}
}

func Test_Get_Assets(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)

	assets, err := ex.Assets(context.Background(), &exchange.GetAssetsRequest{
		APIKey:     "7785315e-4e2a-4631-bbad-3f45705b47f2",
		SecretKey:  "A1DD78E8F058BC74CB090C5B45BFC06F",
		Passphrase: "aXYh@.}aj}v_x@G-3B#J",
	})
	if err != nil {
		t.Fatal(err)
	}
	fmt.Printf("%+v\n", assets)
}

func Test_Get_Config(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)

	config, err := ex.GetAccountConfig(context.Background(), &exchange.GetAccountConfigRequest{
		APIKey:     "7b643dd9-eca4-43e1-a98f-55d216a9a461",
		SecretKey:  "7FD8658FB4DA0A552A3133D956A86880",
		Passphrase: "Aa21887236!",
	})
	if err != nil {
		t.Fatal(err)
	}
	fmt.Printf("%+v\n", config)
}

func Test_Get_Positions(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)

	positions, err := ex.GetPosition(context.Background(), &exchange.GetPositionRequest{
		APIKey:     "7b643dd9-eca4-43e1-a98f-55d216a9a461",
		SecretKey:  "7FD8658FB4DA0A552A3133D956A86880",
		Passphrase: "Aa21887236!",
	})

	if err != nil {
		t.Fatal(err)
	}

	for _, position := range positions {
		fmt.Printf("%+v\n", position)
	}
}

func Test_Get_History_Positions(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)

	err := ex.GetHistoryPosition(context.Background(), &exchange.GetPositionHistoryRequest{
		APIKey:     "70b99d55-54aa-4201-8b78-aca6cbcca79a",
		SecretKey:  "E35B5C536242A8AA01B431D14555E7FE",
		Passphrase: "Aa21887236!",
	})

	if err != nil {
		t.Fatal(err)
	}
}

func Test_Get_Order(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)
	data, err := ex.SearchOrder(context.Background(), &exchange.SearchOrderRequest{
		APIKey:        "46a9e168-6a8a-4919-ad64-1d2a0c59151f",
		SecretKey:     "1D826AB07970BE7C8EB717D87F0C1DE1",
		Passphrase:    "Aa21887236!",
		ClientOrderID: "33662e8050ed4722af4612aebede2b20",
		Symbol: exchange.Symbol{
			OriginalSymbol: "BTC-USDT-241227",
			CtVal:          decimal.NewFromFloat(0.01),
		},
	})
	if err != nil {
		t.Fatal(err)
	}
	fmt.Printf("%+v\n", data)
}

func Test_Get_Positions_V5(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)
	_, err := ex.GetPosition(context.Background(), &exchange.GetPositionRequest{
		APIKey:     "46a9e168-6a8a-4919-ad64-1d2a0c59151f",
		SecretKey:  "1D826AB07970BE7C8EB717D87F0C1DE1",
		Passphrase: "Aa21887236!",
	})
	if err != nil {
		t.Fatal(err)
	}
}

func Test_Set_Leverage(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)
	err := ex.SetLeverage(context.Background(), &exchange.SetLeverageRequest{
		APIKey:     "afa3d119-5858-4d6f-9006-aa4cc59fb60d",
		SecretKey:  "190A1363588D0B38113CBE0D7D04931B",
		Passphrase: "Aa21887236!",
		Symbol:     "BTC-USDT",
		Mode:       "cross",
		Lever:      "10",
	})
	if err != nil {
		t.Fatal(err)
	}
}

func Test_Get_MarkPriceKline(t *testing.T) {
	cli := okhttp.NewClient()
	ex := okexc.NewOkx(cli)
	result, err := ex.GetMarkPriceKline(context.Background(), &exchange.GetMarkPriceKlineRequest{
		Symbol: "BTC-USDT-241011",
		Period: "1H",
		Start:  1728010053000,
		End:    1728370053000,
	})
	if err != nil {
		t.Fatal(err)
	}

	for _, r := range result {
		fmt.Printf("%+v\n", r)
	}
}

func Test_Data_Feed(t *testing.T) {
	limiter := okxlimiter.NewOkxLimiter(newRedis())

	df := dfokx.NewOkxDataFeed(limiter)

	var wg sync.WaitGroup
	wg.Add(10) // 准备三个协程

	for i := 0; i < 10; i++ {
		go func(i int) {
			defer wg.Done() // 协程完成时通知WaitGroup

			err := df.AddDataFeed(&dfmanager.DataFeedRequest{
				ID:           fmt.Sprintf("123456227-%d", i), // 唯一ID
				Symbol:       "ETH-USDT-241227",
				Instrument:   exchange.InstrumentTypeFutures,
				Event:        okmessageEvent(i),
				ErrorHandler: errEvent,
			})

			if err != nil {
				fmt.Println(err)
			}
		}(i)
	}

	wg.Wait() // 等待所有协程完成
	time.Sleep(30 * time.Minute)
}

func Test_Mark_Price(t *testing.T) {
	limiter := okxlimiter.NewOkxLimiter(newRedis())

	df := dfokx.NewOkxDataFeed(limiter)

	var wg sync.WaitGroup
	wg.Add(1) // 准备三个协程

	for i := 0; i < 1; i++ {
		go func(i int) {
			defer wg.Done() // 协程完成时通知WaitGroup

			err := df.AddMarketPriceDataFeed(&dfmanager.MarkPriceRequest{
				ID:           fmt.Sprintf("123456227-%d", i), // 唯一ID
				Symbol:       "ETH-USDT-241227",
				Instrument:   exchange.InstrumentTypeSpot,
				Event:        okMkMessageEvent(i),
				ErrorHandler: errEvent,
			})

			if err != nil {
				fmt.Println(err)
			}
		}(i)
	}

	wg.Wait() // 等待所有协程完成
	time.Sleep(30 * time.Minute)
}

func Test_MarkKline_Price(t *testing.T) {
	limiter := okxlimiter.NewOkxLimiter(newRedis())

	df := dfokx.NewOkxDataFeed(limiter)

	err := df.AddMarketKlineDataFeed(&dfmanager.KlineMarketRequest{
		ID:         "1212121212", // 唯一ID
		Symbol:     "BTC-USDT-250328",
		Period:     "1H",
		Instrument: exchange.InstrumentTypeFutures,
		Event: func(data *exchange.KlineMarketEvent) {
			fmt.Printf("KlineMarketEvent: %v\n", data)
		},
		ErrorHandler: errEvent,
	})

	if err != nil {
		fmt.Println(err)
	}

	time.Sleep(30 * time.Minute)
}

func Test_Symbol_Update(t *testing.T) {
	limiter := okxlimiter.NewOkxLimiter(newRedis())

	df := dfokx.NewOkxDataFeed(limiter)

	err := df.AddSymbolUpdateDataFeed(&dfmanager.SymbolUpdateRequest{
		ID:         "1212121212", // 唯一ID
		Instrument: exchange.InstrumentTypeFutures,
		Event: func(data []*exchange.SymbolUpdateEvent) {
			for _, d := range data {
				fmt.Printf("SymbolUpdateEvent: %v\n", d)
			}
		},
		ErrorHandler: errEvent,
	})

	if err != nil {
		fmt.Println(err)
	}

	time.Sleep(30 * time.Minute)
}

func Test_Okx_Stream(t *testing.T) {
	limiter := okxlimiter.NewOkxLimiter(newRedis())
	of := streamokx.NewOkxStream(httpClient(), newRedis(), limiter, 15*time.Hour)
	instrumentTypeList := []exchange.InstrumentType{exchange.InstrumentTypeSpot, exchange.InstrumentTypeMargin, exchange.InstrumentTypeFutures}
	var wg sync.WaitGroup
	wg.Add(1) // Set for three goroutines

	for i := 0; i < 1; i++ {
		go func(i int) {
			defer wg.Done() // Notify WaitGroup on goroutine completion

			uuid, err := of.AddStream(&streammanager.StreamRequest{
				AccountId:    fmt.Sprintf("12345622-%d", i), // Ensure unique AccountId for each request
				APIKey:       OKAPIKey,
				SecretKey:    OKAPISecret,
				Passphrase:   OKPASSPHRASE,
				Instrument:   instrumentTypeList[i],
				OrderEvent:   orderResultEvent,
				AccountEvent: accountUpdateEvent,
				ErrorHandler: errEvent,
			})

			if err != nil {
				t.Error(err)
			} else {
				fmt.Println(uuid)
			}
		}(i)
	}

	wg.Wait() // Wait for all goroutines to complete
	time.Sleep(40 * time.Minute)
}

func okmessageEvent(i int) func(*exchange.TradeEvent) {
	return func(data *exchange.TradeEvent) {
		fmt.Printf("i:%v TradeEvent: %v\n", i, data)
	}
}

func okMkMessageEvent(i int) func(*exchange.MarkPriceEvent) {
	return func(data *exchange.MarkPriceEvent) {
		fmt.Printf("i:%v MarkPriceEvent: %v\n", i, data)
	}
}
