package test

import (
	"context"
	"encoding/json"
	"fmt"
	"testing"
	"time"

	"github.com/go-gotop/kit/dfmanager"
	"github.com/go-gotop/kit/dfmanager/dfbinance"
	"github.com/go-gotop/kit/exchange"
	"github.com/go-gotop/kit/exchange/bnexc"
	"github.com/go-gotop/kit/limiter/bnlimiter"
	"github.com/go-gotop/kit/requests/bnhttp"
	"github.com/go-gotop/kit/streammanager"
	"github.com/go-gotop/kit/streammanager/streambinance"
	"github.com/google/uuid"
	"github.com/shopspring/decimal"
	"github.com/stretchr/testify/assert"
)

const (
	APIKey     = "HyVTOAZ6Uvc0J7PDGdbMqJeLaj4Lfq0p5l4xjIlrenxtcBSb5PkDZH2pNTnFEev6"
	SecretKey  = "s7bnWapgE4NCWmJhgFaz4F3mvkrp15KtOjPLQRqYIvync1prjVEWLBKSMlNNcu3s"
	UAPIKey    = "gOsrZd9uaqZZMs6GqXeyZXhTno8Vz2rh8f4SgpbJ8kneBZar0JRMzoCvh8CZppR0"
	USecretKey = "59SjLJBaWJkB9ls8IWnf6w4wN40jJ3xky0Tb7r8kyEMltxLOgRCsXGyM9OUZFOIN"
)

func orderResultEvent(evt *exchange.OrderResultEvent) {
	// fmt.Printf("OrderResultEvent: %v\n", evt)
	// 转为json字符串
	data, _ := json.Marshal(evt)
	fmt.Println("OrderResultEvent: ", string(data))

}

func accountUpdateEvent(evt []*exchange.AccountUpdateEvent) {
	for _, v := range evt {
		fmt.Printf("AccountUpdateEvent: %v\n", v)
	}
}

func newHttpClient() *bnhttp.Client {
	return bnhttp.NewClient()
}

func TestAddKlineDataFeed(t *testing.T) {
	limiter := bnlimiter.NewBinanceLimiter(newRedis())

	df := dfbinance.NewBinanceDataFeed(limiter)
	uuid := uuid.New().String()
	err := df.AddKlineDataFeed(&dfmanager.KlineRequest{
		ID:           uuid,
		Symbol:       "BTCUSDT",
		Period:       "1m",
		StartTime:    0,
		EndTime:      0,
		Instrument:   exchange.InstrumentTypeSpot,
		Event:        func(data *exchange.KlineEvent) { fmt.Printf("KlineEvent: %v\n", data) },
		ErrorHandler: errEvent,
	})
	assert.Nil(t, err)

	// 构造订阅消息
	msg := map[string]interface{}{
		"method": "SUBSCRIBE",
		"params": []string{
			"btcusdt@kline_1m",
			"ethusdt@kline_1m",
		},
		"id": 1,
	}

	time.Sleep(5 * time.Second)

	// 转换为JSON字节
	msgBytes, err := json.Marshal(msg)
	assert.Nil(t, err)

	// 发送订阅消息
	err = df.WriteMessage(uuid, msgBytes)
	assert.Nil(t, err)

	time.Sleep(10 * time.Minute)

	err = df.CloseDataFeed(uuid)
	assert.Nil(t, err)
}

func TestGetKline(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	kline, err := binance.GetKline(context.Background(), &exchange.GetKlineRequest{
		Symbol:         exchange.Symbol{OriginalSymbol: "BTCUSDT"},
		Start:          1737761178922,
		// End:            0,
		Period:         "1m",
		Limit:          50,
		InstrumentType: exchange.InstrumentTypeSpot,
	})
	if err != nil {
		t.Fatal(err)
	}
	for _, v := range kline {
		fmt.Println(v)
	}
}

func TestGetDepth(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	depth, err := binance.GetDepth(context.Background(), &exchange.GetDepthRequest{
		Symbol:         exchange.Symbol{OriginalSymbol: "BTCUSDT"},
		Limit:          10,
		InstrumentType: exchange.InstrumentTypeFutures,
	})
	if err != nil {
		t.Fatal(err)
	}

	fmt.Printf("%+v\n", depth)
}

func TestNewOwf(t *testing.T) {
	limiter := bnlimiter.NewBinanceLimiter(newRedis())

	of := streambinance.NewBinanceStream(newHttpClient(), newRedis(), limiter, 23*time.Hour)

	uuid, err := of.AddStream(&streammanager.StreamRequest{
		AccountId:    "123456",
		APIKey:       APIKey,
		SecretKey:    SecretKey,
		Instrument:   exchange.InstrumentTypeFutures,
		OrderEvent:   orderResultEvent,
		AccountEvent: accountUpdateEvent,
	})

	if err != nil {
		t.Error(err)
	}

	fmt.Println(uuid)

	time.Sleep(10 * time.Minute)
}

func TestSearchOrder(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	res, err := binance.SearchOrder(context.Background(), &exchange.SearchOrderRequest{
		APIKey:         APIKey,
		SecretKey:      SecretKey,
		Symbol:         exchange.Symbol{OriginalSymbol: "BTCUSDT"},
		ClientOrderID:  "3a638861-f0ce-4d7a-ad90-54d437b0a8a8",
		InstrumentType: exchange.InstrumentTypeSpot,
	})
	if err != nil {
		t.Error(err)
	}
	fmt.Println(res)

	res, err = binance.SearchOrder(context.Background(), &exchange.SearchOrderRequest{
		APIKey:         APIKey,
		SecretKey:      SecretKey,
		Symbol:         exchange.Symbol{OriginalSymbol: "BTCUSDT"},
		ClientOrderID:  "366967368526",
		InstrumentType: exchange.InstrumentTypeFutures,
	})
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	fmt.Println(res)
}

func TestSearchTrades(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	res, err := binance.SearchTrades(context.Background(), &exchange.SearchTradesRequest{
		APIKey:         APIKey,
		SecretKey:      SecretKey,
		Symbol:         "BTCUSDT",
		OrderID:        "28141806895",
		InstrumentType: exchange.InstrumentTypeSpot,
	})
	if err != nil {
		t.Error(err)
	}
	for _, v := range res {
		fmt.Println(v)
	}

	res, err = binance.SearchTrades(context.Background(), &exchange.SearchTradesRequest{
		APIKey:         APIKey,
		SecretKey:      SecretKey,
		Symbol:         "BTCUSDT",
		OrderID:        "366967368526",
		InstrumentType: exchange.InstrumentTypeFutures,
	})
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	for _, v := range res {
		fmt.Println(v)
	}
}

func TestFundingRate(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	res, err := binance.GetFundingRate(context.Background(), &exchange.GetFundingRate{
		// Symbol: "BTCUSDT",
	})
	if err != nil {
		t.Error(err)
	}
	for _, v := range res {
		fmt.Println(v)
	}
}

func TestMarginInterestRate(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	res, err := binance.GetMarginInterestRate(context.Background(), &exchange.GetMarginInterestRateRequest{
		APIKey:     APIKey,
		SecretKey:  SecretKey,
		Assets:     "BTC,ETH,ORDI",
		IsIsolated: false,
	})
	if err != nil {
		t.Error(err)
	}
	for _, v := range res {
		fmt.Println(v)
	}
}

func TestMarginInventory(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	res, err := binance.GetMarginInventory(context.Background(), &exchange.MarginInventoryRequest{
		APIKey:    APIKey,
		SecretKey: SecretKey,
		Typ:       exchange.MarginTypeMargin,
	})
	if err != nil {
		t.Error(err)
	}
	fmt.Printf("MarginInventory: %v\n", len(res.Assets))
	// fmt.Println(res)
}

func TestBorrowMargin(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	err := binance.MarginBorrowOrRepay(context.Background(), &exchange.MarginBorrowOrRepayRequest{
		APIKey:     APIKey,
		SecretKey:  SecretKey,
		Asset:      "TRX",
		IsIsolated: false,
		Amount:     decimal.NewFromFloat(10),
		Typ:        "BORROW",
	})
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
}

func TestCreateOrder(t *testing.T) {
	binance := bnexc.NewBinance(newHttpClient())
	createErr := binance.CreateOrder(context.Background(), &exchange.CreateOrderRequest{
		APIKey:           UAPIKey,
		SecretKey:        USecretKey,
		OrderTime:        time.Now().UnixNano() / 1e6,
		Symbol:           exchange.Symbol{OriginalSymbol: "ETHUSDT"},
		ClientOrderID:    "TEST12121212",
		Side:             exchange.SideTypeBuy,
		OrderType:        exchange.OrderTypeMarket,
		PositionSide:     exchange.PositionSideLong,
		Instrument:       exchange.InstrumentTypeFutures,
		Size:             decimal.NewFromFloat(0.01),
		IsUnifiedAccount: true,
	})
	if createErr != nil {
		fmt.Printf("error: %v\n", createErr)
	}
}

// func TestCreateUniOrder(t *testing.T) {
// 	// 生成一个新的 UUID
// 	newUUID := uuid.New()

// 	// 将 UUID 格式化为32个字符的字符串（去除连字符）
// 	uuid32 := strings.ReplaceAll(newUUID.String(), "-", "")

// 	binance := bnexc.NewBinance(newHttpClient())
// 	createErr := binance.CreateOrder(context.Background(), &exchange.CreateOrderRequest{
// 		APIKey:           UAPIKey,
// 		SecretKey:        USecretKey,
// 		OrderTime:        time.Now().UnixNano() / 1e6,
// 		Symbol:           "ETHUSDT",
// 		ClientOrderID:    uuid32,
// 		Side:             exchange.SideTypeSell,
// 		OrderType:        exchange.OrderTypeMarket,
// 		PositionSide:     exchange.PositionSideLong,
// 		Instrument:       exchange.InstrumentTypeMargin,
// 		Size:             decimal.NewFromFloat(0.002),
// 		IsUnifiedAccount: true,
// 	})
// 	if createErr != nil {
// 		fmt.Printf("error: %v\n", createErr)
// 	}
// }

func TestBinanceOf(t *testing.T) {
	limiter := bnlimiter.NewBinanceLimiter(newRedis())

	of := streambinance.NewBinanceStream(newHttpClient(), newRedis(), limiter, 23*time.Hour)

	uuid, err := of.AddStream(&streammanager.StreamRequest{
		AccountId:        "5",
		APIKey:           UAPIKey,
		SecretKey:        USecretKey,
		Instrument:       exchange.InstrumentTypeMargin,
		OrderEvent:       mockOrderResultEvent,
		ErrorHandler:     errEvent,
		IsUnifiedAccount: true,
	})

	if err != nil {
		fmt.Printf("error: %v\n", err)
	}

	fmt.Println(uuid)

	time.Sleep(10 * time.Minute)
}
