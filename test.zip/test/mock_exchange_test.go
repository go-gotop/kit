package test

import (
	"context"
	"fmt"
	"testing"
	"time"

	"github.com/go-gotop/kit/dfmanager"
	"github.com/go-gotop/kit/dfmanager/dfmock"
	"github.com/go-gotop/kit/exchange"
	"github.com/go-gotop/kit/exchange/moexc"
	"github.com/go-gotop/kit/limiter/molimiter"
	"github.com/go-gotop/kit/requests/mohttp"
	"github.com/go-gotop/kit/streammanager"
	"github.com/go-gotop/kit/streammanager/streammock"
	"github.com/google/uuid"
	"github.com/stretchr/testify/assert"
)

const (
	APIKEY = "1212121212121"
	SECRET = "1212121212121"
)

func Test_mock_exchange(t *testing.T) {
	http := mohttp.NewClient()
	moc := moexc.NewMockExchange(http)

	assets, err := moc.Assets(context.Background(), &exchange.GetAssetsRequest{
		APIKey:         APIKEY,
		SecretKey:      SECRET,
		InstrumentType: exchange.InstrumentTypeFutures,
	})
	if err != nil {
		fmt.Printf("error: %v\n", err)
	}
	fmt.Println(assets)
}

// func Test_create_order(t *testing.T) {
// 	http := mohttp.NewClient()
// 	moc := moexc.NewMockExchange(http,moexc.WithMockExchangEndpoint("http://192.168.100.3:8070"))

// 	err := moc.CreateOrder(context.Background(), &exchange.CreateOrderRequest{
// 		APIKey:        APIKEY,
// 		SecretKey:     SECRET,
// 		OrderTime:     1673656619999,
// 		Symbol:        "ETHUSDT",
// 		ClientOrderID: uuid.New().String(),
// 		Side:          exchange.SideTypeBuy,
// 		OrderType:     exchange.OrderTypeMarket,
// 		PositionSide:  exchange.PositionSideLong,
// 		Instrument:    exchange.InstrumentTypeSpot,
// 		Size:          decimal.NewFromFloat(1),
// 	})
// 	if err != nil {
// 		fmt.Printf("error: %v\n", err)
// 	}
// }

func Test_GetInventory(t *testing.T) {
	http := mohttp.NewClient()
	moc := moexc.NewMockExchange(http, moexc.WithMockExchangEndpoint("http://127.0.0.1:8070"))

	data, err := moc.GetMarginInventory(context.Background(), &exchange.MarginInventoryRequest{
		APIKey:    APIKEY,
		SecretKey: "12121111",
		Typ:       exchange.MarginTypeMargin,
	})

	if err != nil {
		fmt.Printf("error: %v\n", err)
	}

	fmt.Println(data)
}

func mockOrderResultEvent(evt *exchange.OrderResultEvent) {
	fmt.Printf("OrderResultEvent: %v\n", evt)
}

func newMockHttpClient() *mohttp.Client {
	return mohttp.NewClient()
}

func Test_of(t *testing.T) {
	limiter := molimiter.NewMockLimiter(newRedis())

	of := streammock.NewMockStream(newMockHttpClient(), limiter, streammock.WithWsEndpoint("ws://127.0.0.1:8073/ws/order"), streammock.WithMockExchangEndpoint("http://192.168.1.105:8070"))

	uuid, err := of.AddStream(&streammanager.StreamRequest{
		AccountId:    "1",
		APIKey:       APIKEY,
		SecretKey:    SECRET,
		Instrument:   exchange.InstrumentTypeFutures,
		OrderEvent:   mockOrderResultEvent,
		ErrorHandler: errEvent,
	})

	if err != nil {
		fmt.Printf("error: %v\n", err)
	}

	fmt.Println(uuid)

	time.Sleep(10 * time.Minute)
}

func Test_df(t *testing.T) {
	limiter := molimiter.NewMockLimiter(newRedis())

	df := dfmock.NewMockDataFeed(limiter)
	assert.NotNil(t, df)
	uuid := uuid.New().String()
	err := df.AddDataFeed(&dfmanager.DataFeedRequest{
		ID:           uuid,
		Symbol:       "BTCUSDT",
		Instrument:   exchange.InstrumentTypeFutures,
		StartTime:    1603351706000,
		EndTime:      1603438106000,
		Event:        dataFeedEvent,
		ErrorHandler: errEvent,
	})

	if err != nil {
		fmt.Printf("error: %v\n", err)
	}

	assert.Nil(t, err)

	time.Sleep(1 * time.Minute)
}

// 记录上一次订单时间
var lastOrderTime int64 = 0
var preBuy = false

func dataFeedEvent(event *exchange.TradeEvent) {
	fmt.Printf("data: %v\n", event)
	// currentEventTime := event.TradedAt
	// 每10分钟触发一次订单操作
	// if lastOrderTime == 0 || currentEventTime-lastOrderTime >= 10*60*1000 {
	// 	fmt.Print("create order\n")
	// 	createAndCloseOrder(event.Symbol, event.Instrument, event.TradedAt)
	// 	lastOrderTime = currentEventTime
	// }
}

// func createAndCloseOrder(symbol string, instrument exchange.InstrumentType, tradedAt int64) {
// 	http := mohttp.NewClient()
// 	moc := moexc.NewMockExchange(http)
// 	if !preBuy {
// 		// 创建一个订单
// 		createErr := moc.CreateOrder(context.Background(), &exchange.CreateOrderRequest{
// 			APIKey:        APIKEY,
// 			SecretKey:     SECRET,
// 			OrderTime:     tradedAt,
// 			Symbol:        symbol,
// 			ClientOrderID: uuid.New().String(),
// 			Side:          exchange.SideTypeBuy,
// 			OrderType:     exchange.OrderTypeMarket,
// 			PositionSide:  exchange.PositionSideLong,
// 			Instrument:    instrument,
// 			Size:          decimal.NewFromFloat(1),
// 		})

// 		if createErr != nil {
// 			fmt.Printf("Failed to create order: %v\n", createErr)
// 			return
// 		}

// 		preBuy = true
// 	} else {
// 		// 创建一个订单
// 		createErr := moc.CreateOrder(context.Background(), &exchange.CreateOrderRequest{
// 			APIKey:        APIKEY,
// 			SecretKey:     SECRET,
// 			OrderTime:     tradedAt,
// 			Symbol:        symbol,
// 			ClientOrderID: uuid.New().String(),
// 			Side:          exchange.SideTypeSell,
// 			OrderType:     exchange.OrderTypeMarket,
// 			PositionSide:  exchange.PositionSideLong,
// 			Instrument:    instrument,
// 			Size:          decimal.NewFromFloat(1),
// 		})

// 		if createErr != nil {
// 			fmt.Printf("Failed to create order: %v\n", createErr)
// 			return
// 		}

// 		preBuy = false
// 	}
// }
