package test

import (
	"fmt"
	"testing"

	"github.com/go-gotop/kit/sms"
	"github.com/go-gotop/kit/sms/tencent"
)

func Test_Tencent_Sms(t *testing.T) {
	tencent, err := tencent.NewSmsTencent(
		tencent.WithSecretID(""),
		tencent.WithSecretKey(""),
		tencent.WithAppID(""),
		tencent.WithUserSession("test_user"),
		tencent.WithTimeOut(10),
	)

	if err != nil {
		fmt.Print(err)
	}

	tencent.SendMobile(&sms.SendMobileRequest{
		TemplateParam: []string{"1%", "2%"},
		TemplateID:    "2913458",
		PhoneNumbers:  []string{"+85239154802"},
	})
}
