package test

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"log"
	"os"
	"testing"
	"time"

	kafka "github.com/segmentio/kafka-go"
)

const (
	testBrokers1 = "192.168.1.224:9094"
	// testBrokers = "192.168.1.107:9094"
	testTopic1   = "order-event"
	testGroupId1 = "fx-group1"
	// certFile    = "../keystore/server/client-signed.crt"
	clientKey1  = "./tls/server-key.pem"
	clientCert1 = "./tls/server-cert.pem"
	caFile1     = "./tls/ca-cert.pem"
)

func generateTLSConfig() *tls.Config {
	// Load client cert
	cert, err := tls.LoadX509KeyPair(clientCert1, clientKey1)
	if err != nil {
		log.Fatal(err)
	}

	// Load CA cert
	caCert, err := os.ReadFile(caFile1)
	if err != nil {
		log.Fatal(err)
	}
	caCertPool := x509.NewCertPool()
	caCertPool.AppendCertsFromPEM(caCert)

	return &tls.Config{
		Certificates: []tls.Certificate{cert},
		RootCAs:      caCertPool,
		// InsecureSkipVerify: false,
	}
}

func Test_tls_read(t *testing.T) {

	r := kafka.NewReader(kafka.ReaderConfig{
		Brokers:   []string{testBrokers1},
		Topic:     testTopic1,
		Partition: 0,
		MinBytes:  10e3, // 10KB
		MaxBytes:  10e6, // 10MB
		Dialer: &kafka.Dialer{
			Timeout:   10 * time.Second,
			DualStack: true,
			TLS:       generateTLSConfig(),
		},
	})

	// 读取消息
	m, err := r.ReadMessage(context.Background())
	if err != nil {
		t.Fatalf("failed to read messages: %v", err)
	}

	fmt.Printf("message at topic/partition/offset %v/%v/%v: %s = %s\n", m.Topic, m.Partition, m.Offset, string(m.Key), string(m.Value))

	time.Sleep(30 * time.Second)
}

func Test_tls_write(t *testing.T) {
	w := kafka.NewWriter(kafka.WriterConfig{
		Brokers:  []string{testBrokers1},
		Topic:    testTopic1,
		Balancer: &kafka.LeastBytes{},
		Dialer: &kafka.Dialer{
			Timeout:   10 * time.Second,
			DualStack: true,
			TLS:       generateTLSConfig(),
		},
	})

	// 写入消息
	msg := kafka.Message{
		Key:   []byte("Key"),
		Value: []byte("Hello World!"),
	}
	err := w.WriteMessages(context.Background(), msg)
	if err != nil {
		t.Fatalf("failed to write messages: %v", err)
	}

	time.Sleep(30 * time.Second)
}
